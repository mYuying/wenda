package com.myy.wenda.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

@Service
@Configuration
@EnableConfigurationProperties(RedisConfig.class)
public class RedisPoolFactory {
    @Autowired
    static RedisConfig redisConfig;

    @Value("${redis.host:127.0.0.1}")
    static String host;

    @Autowired
    Environment env;

    @Bean
    public JedisPool JedisPoolFactory(){
        JedisPoolConfig poolconfig = new JedisPoolConfig();
        poolconfig.setMaxIdle(redisConfig.getPoolMaxIdle());
        poolconfig.setMaxTotal(redisConfig.getPoolMaxTotal());
        poolconfig.setMaxWaitMillis(redisConfig.getPoolMaxWait() *1000);
        JedisPool jp = new JedisPool(poolconfig,redisConfig.getHost(),redisConfig.getPort(),
                redisConfig.getTimeout()*1000,redisConfig.getPassword());
        return jp;
    }

    public static void main(String[] args) {
        RedisPoolFactory redisPoolFactory = new RedisPoolFactory();
        System.out.println(redisPoolFactory.env.getProperty("redis.host"));
    }
}
